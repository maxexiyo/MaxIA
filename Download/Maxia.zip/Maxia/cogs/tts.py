import discord
from discord.ext import commands
from database import db
import logging
import edge_tts
import asyncio
import os
import time
from pathlib import Path

logger = logging.getLogger(__name__)

TTS_FOLDER = Path(__file__).parent.parent / 'tts_audios'
TTS_FOLDER.mkdir(exist_ok=True)

class TTS(commands.Cog):
    """Cog para text-to-speech ultra rápido usando edge-tts con control de timeout"""
    
    def __init__(self, bot):
        self.bot = bot
        self.vc_readers = {}  
    
    async def _audio_worker(self, guild_id):
        """Procesa la cola de audios de manera secuencial con timeout de seguridad de 10s"""
        while guild_id in self.vc_readers and self.vc_readers[guild_id]['enabled']:
            try:
                queue = self.vc_readers[guild_id]['queue']
                file_path = await queue.get()
                
                guild = self.bot.get_guild(guild_id)
                voice_client = discord.utils.get(self.bot.voice_clients, guild=guild)
                
                if not voice_client or not voice_client.is_connected():
                    queue.task_done()
                    if file_path.exists():
                        file_path.unlink(missing_ok=True)
                    continue
                
                # Esperar a que el archivo esté listo con un límite máximo de 10 segundos
                start_time = asyncio.get_event_loop().time()
                while not file_path.exists() or file_path.stat().st_size == 0:
                    if asyncio.get_event_loop().time() - start_time > 10.0:
                        logger.warning(f'Timeout: El archivo {file_path.name} tardó más de 10s. Saltando elemento.')
                        break
                    await asyncio.sleep(0.05)
                
                # Si tras el tiempo límite el archivo sigue sin existir o está vacío, descartar y continuar
                if not file_path.exists() or file_path.stat().st_size == 0:
                    queue.task_done()
                    if file_path.exists():
                        file_path.unlink(missing_ok=True)
                    continue
                
                event = asyncio.Event()
                
                def after_playing(error):
                    if error:
                        logger.error(f'Error en reproducción de audio: {error}')
                    if file_path.exists():
                        file_path.unlink(missing_ok=True)
                    self.bot.loop.call_soon_threadsafe(event.set)
                
                source = discord.FFmpegPCMAudio(str(file_path))
                voice_client.play(source, after=after_playing)
                
                await event.wait()
                queue.task_done()
                
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f'Error en el worker de TTS: {e}')
                await asyncio.sleep(1)
    
    @commands.command(name='leervc')
    async def leervc(self, ctx):
        """Activar lectura en el canal de voz"""
        
        if not ctx.author.voice or not ctx.author.voice.channel:
            await ctx.send('❌ Debes estar en un canal de voz.')
            return
            
        channel = ctx.author.voice.channel
        
        if not ctx.voice_client:
            await channel.connect()
        elif ctx.voice_client.channel != channel:
            await ctx.voice_client.move_to(channel)
        
        guild_id = ctx.guild.id
        
        if guild_id not in self.vc_readers:
            queue = asyncio.Queue()
            task = self.bot.loop.create_task(self._audio_worker(guild_id))
            self.vc_readers[guild_id] = {
                'enabled': True,
                'text_channel_id': ctx.channel.id,
                'voice': db.get_config(guild_id, 'tts_voice', 'es-MX-DaliaNeural'),
                'last_author_id': None,
                'last_time': 0,
                'queue': queue,
                'task': task
            }
        else:
            self.vc_readers[guild_id]['enabled'] = True
            self.vc_readers[guild_id]['text_channel_id'] = ctx.channel.id
            self.vc_readers[guild_id]['last_author_id'] = None
            self.vc_readers[guild_id]['last_time'] = 0
            
            if 'task' not in self.vc_readers[guild_id] or self.vc_readers[guild_id]['task'].done():
                self.vc_readers[guild_id]['queue'] = asyncio.Queue()
                self.vc_readers[guild_id]['task'] = self.bot.loop.create_task(self._audio_worker(guild_id))
        
        await ctx.send(f'🔊 Conectado y leyendo con alta velocidad en {channel.mention}')
        logger.info(f'TTS edge-tts activado en {ctx.guild.name}')
    
    @commands.command(name='dejardeleer')
    async def dejardeleer(self, ctx):
        """Desactivar lectura en el canal de voz"""
        
        guild_id = ctx.guild.id
        
        if guild_id in self.vc_readers:
            self.vc_readers[guild_id]['enabled'] = False
            
            if 'task' in self.vc_readers[guild_id]:
                self.vc_readers[guild_id]['task'].cancel()
                
            if ctx.voice_client:
                await ctx.voice_client.disconnect()
                
            await ctx.send('🔇 Lectura desactivada y desconectado.')
            logger.info(f'TTS desactivado en {ctx.guild.name}')
        else:
            await ctx.send('❌ La lectura no está activada.')

    @commands.command(name='setvoz')
    @commands.has_permissions(administrator=True)
    async def set_voice(self, ctx, voice: str = None):
        """Establecer voz neuronal (ej: es-MX-DaliaNeural, es-ES-AlvaroNeural, en-US-AriaNeural)"""
        
        if voice is None:
            await ctx.send('❌ Ejemplo de voces: `es-MX-DaliaNeural`, `es-ES-AlvaroNeural`, `en-US-AriaNeural`')
            return
        
        guild_id = ctx.guild.id
        db.set_config(guild_id, 'tts_voice', voice)
        
        if guild_id in self.vc_readers:
            self.vc_readers[guild_id]['voice'] = voice
        
        await ctx.send(f'✅ Voz establecida a `{voice}`')
    
    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        """Leer mensajes en VC generando el audio de forma rápida y asíncrona"""
        
        if message.author.bot:
            return
            
        if message.content.startswith('!max'):
            return
        
        guild_id = message.guild.id
        if guild_id not in self.vc_readers or not self.vc_readers[guild_id]['enabled']:
            return
            
        voice_client = discord.utils.get(self.bot.voice_clients, guild=message.guild)
        if not voice_client or not voice_client.is_connected():
            return
            
        text_channel_id = self.vc_readers[guild_id].get('text_channel_id')
        if text_channel_id and message.channel.id != text_channel_id:
            return
            
        if not message.author.voice or message.author.voice.channel != voice_client.channel:
            return
            
        voice_name = self.vc_readers[guild_id].get('voice', 'es-MX-DaliaNeural')
        
        current_time = time.time()
        last_author_id = self.vc_readers[guild_id].get('last_author_id')
        last_time = self.vc_readers[guild_id].get('last_time', 0)
        
        if last_author_id == message.author.id and (current_time - last_time) < 60:
            text_to_read = message.content
        else:
            text_to_read = f"{message.author.display_name} dice: {message.content}"
            
        self.vc_readers[guild_id]['last_author_id'] = message.author.id
        self.vc_readers[guild_id]['last_time'] = current_time
        
        try:
            file_path = TTS_FOLDER / f"tts_{guild_id}_{int(time.time()*1000)}_{os.urandom(2).hex()}.mp3"
            
            communicate = edge_tts.Communicate(text_to_read, voice_name)
            await communicate.save(str(file_path))
            
            queue = self.vc_readers[guild_id].get('queue')
            if queue:
                await queue.put(file_path)
            
        except Exception as e:
            logger.error(f'Error al generar edge-tts: {e}')

async def setup(bot):
    await bot.add_cog(TTS(bot))