import json
import os
from playwright.sync_api import sync_playwright

def generate_browser_json():
    print("🚀 Abriendo navegador para iniciar sesión en YouTube Music...")
    with sync_playwright() as p:
        # Abrir el navegador ocultando las banderas de automatización de Playwright
        browser = p.chromium.launch(
            headless=False,
            args=["--disable-blink-features=AutomationControlled"]
        )
        context = browser.new_context()
        page = context.new_page()
        
        # Ir a YouTube Music
        page.goto("https://music.youtube.com")
        
        print("\n" + "="*50)
        print("👉 INSTRUCCIONES:")
        print("1. Inicia sesión en la ventana del navegador que se acaba de abrir con la cuenta de Google de tu bot.")
        print("2. Resuelve cualquier verificación o captcha si te lo pide.")
        print("3. Asegúrate de estar en la página principal de YouTube Music ya logueado.")
        print("="*50 + "\n")
        
        input("👉 Presiona [ENTER] en esta consola UNA VEZ QUE HAYAS TERMINADO DE INICIAR SESIÓN...")
        
        # Obtener las cookies de la sesión
        cookies = context.cookies("https://music.youtube.com")
        cookie_string = "; ".join([f"{c['name']}={c['value']}" for c in cookies])
        
        # Obtener el User-Agent del navegador real
        user_agent = page.evaluate("navigator.userAgent")
        
        browser.close()

    # Estructura requerida para ytmusicapi y yt-dlp
    browser_data = {
        "User-Agent": user_agent,
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
        "Accept-Language": "es-ES,es;q=0.9,en;q=0.8",
        "X-Goog-AuthUser": "0",
        "Cookie": cookie_string
    }

    # Guardar en browser.json
    with open("browser.json", "w", encoding="utf-8") as f:
        json.dump(browser_data, f, indent=4, ensure_ascii=False)

    print("\n✅ ¡Listo! El archivo 'browser.json' se ha generado y actualizado correctamente con tus credenciales.")

if __name__ == "__main__":
    generate_browser_json()
    