"""Titulares de Latinoamérica desde Google News (RSS, sin API key)."""
import asyncio
import logging
import random
import xml.etree.ElementTree as ET

import aiohttp

logger = logging.getLogger(__name__)

PAISES = {"MX": "México", "AR": "Argentina", "CO": "Colombia", "CL": "Chile", "PE": "Perú", "VE": "Venezuela"}


async def _rss(sesion: aiohttp.ClientSession, cod: str) -> list:
    url = f"https://news.google.com/rss?hl=es-419&gl={cod}&ceid={cod}:es-419"
    try:
        async with sesion.get(url, headers={"User-Agent": "Mozilla/5.0"}) as r:
            if r.status != 200:
                return []
            texto = await r.text()
        items = []
        for it in ET.fromstring(texto).iter("item"):
            titulo = (it.findtext("title") or "").strip()
            fuente_el = it.find("source")
            fuente = (fuente_el.text or "").strip() if fuente_el is not None else ""
            if fuente and titulo.endswith(" - " + fuente):
                titulo = titulo[:-(len(fuente) + 3)]
            elif not fuente and " - " in titulo:
                titulo, fuente = titulo.rsplit(" - ", 1)
            if titulo:
                items.append({"titulo": titulo, "fuente": fuente or "Google Noticias", "pais": PAISES[cod],
                              "url": (it.findtext("link") or "").strip()})
        return items
    except Exception as e:
        logger.warning(f"[radio] noticias {cod} falló: {e!r}")
        return []


async def obtener_noticias(max_total: int = 4, excluir=None) -> list:
    """Hasta `max_total` titulares de países distintos. `excluir` = títulos que ya se dieron."""
    excluir = excluir or set()
    async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=15)) as s:
        listas = await asyncio.gather(*[_rss(s, c) for c in PAISES])
    listas = [[n for n in l if n["titulo"] not in excluir] for l in listas if l]
    random.shuffle(listas)
    elegidas = []
    ronda = 0
    while len(elegidas) < max_total and any(len(l) > ronda for l in listas):
        for l in listas:
            if len(l) > ronda and len(elegidas) < max_total:
                elegidas.append(l[ronda])
        ronda += 1
    return elegidas
